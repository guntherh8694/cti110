frst_num = int(input('Enter first number:\n'))

scnd_num2 = int(input('Enter second number:\n'))

print(frst_num)

print(scnd_num2)

print(frst_num + scnd_num2)

print(frst_num * scnd_num2)









